# AI-Based Campus Space Intelligence System (Demo)
Static decision-support prototype: HTML5, CSS3, vanilla JavaScript, Chart.js via CDN. All data is fictional and simulated. No backend, sensors, login or database.

## Files
`index.html`; `assets/css/style.css`; `assets/js/`: `data.js` (sample data), `storage.js` (localStorage + reset), `utils.js` (shared formulas), `prediction.js` (k-NN, MAE/RMSE), `scheduling.js` (rules), `environment.js` (thresholds, alerts), `app.js` (pages, events).

## Run locally
Open `index.html` in a browser (internet needed once for the Chart.js CDN).

## Deploy to GitHub Pages
1. Create a repository and upload the whole folder contents (keep `assets/`). 2. Commit. 3. Settings > Pages. 4. Source: "Deploy from a branch", branch `main`, folder `/ (root)`. 5. Save, wait about a minute, open the shown URL.
Troubleshooting: blank page or missing styles means wrong paths (keep `assets/css` and `assets/js` exactly); press F12 > Console for JavaScript errors; charts missing means the CDN is blocked.

## Test checklist (you still need to run these in a browser)
- Dashboard: cards match tables; utilization = occupancy / capacity x 100; 3 environment alerts, capacity alerts for LR-102 and CL-101, schedule alerts for s1/s2 overlap.
- Prediction: result is 0..capacity; class size above capacity or k=0 shows an error; MAE/RMSE shown with 280 test records and the baseline.
- Scheduling: an overlapping request shows the overlap reason; 300 attendees returns Auditorium only; 500 attendees shows "No suitable room"; 09:00-10:00 after an 08:00-09:00 booking is not a conflict.
- Environment: units are correct; SR-101 CO₂ shows "No data" with no alert; edit `ENV.limits` and reload to see alerts change.
- Rooms/storage: search and filters work; add a room, refresh, it persists; Reset restores samples.
- General: navigation, mobile width, no console errors.

## Limitations
Simulated data only; evaluation scores do not show real-world accuracy; the scheduler is a simple rule engine; localStorage is per browser and not shared; no authentication. Future work: authorized campus data, real sensors, a backend.
